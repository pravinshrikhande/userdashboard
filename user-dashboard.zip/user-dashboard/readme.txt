=== User-dashboard ===
Contributors: anildhiman
Donate link: http://mecontact.wordpress.com/user-dashboard/
Tags: user plugin, dashboard plugin, user-dashboard, front-end dashboard, 
user front-end dashboard, wordpress front-end dashboard, wordpress front-end user, frontend controller
Requires at least: 3.0
Tested up to: 3.5
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

User-Dashboard

== Description ==

<p>User-dashboard is a simple and easy to integrate with any design and easy to change in coding as per requirement and easy to 
handle . client can easy integrate this using [user-dahsboard] tag in page editor. these are multiple features that this plugin consist. User-dashboard provide you 
totally different section for front-end users in wordpress. it provides you login, registration and forgot password from front-end. and also provide
you different section separate from wp-admin to access user area where user can edit their profile easily without entering admin area.
</p>
<ul>
<li> - Login.</li>
<li> - Registration.</li>
<li> - Forgot passwored.</li>
<li> - Edit profile.</li>
<li> - Edit profile pic.</li>

</ul>

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload 'User-dashboard' folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Place `[user-dashboard]` in your page editor or in templates paste this code udashboard();


== Frequently Asked Questions ==

= Installed the plugin, added [user-dashboard] to my page, but i see the code only. =

Try to enter in the html mode not the text mode in admin section

= And i have a message with an update to 0.0 version but when click on it, it looks like the plugin was updated, but not. =

This problem is resolved.

= I have waited for a plugin like this, great. But when I istalled the plugin it dont work. When I open the button profile in the user area it says the page dont exist. =

Please reset your permalink it will resolve the problem.

== Screenshots ==
1. After login dashboard
2. Before login dashboard
3. Login screen
4. Registration screen
5. Forgot password screen
6. Profile pic screen
7. Profile edit screen

== Changelog ==
= 1.0 =

== Upgrade Notice ==

Nothing to say