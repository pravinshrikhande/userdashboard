<?php
class MJdashboard{
	function LogScreen() {
	$new_query = add_query_arg(array('ac' => 'login'), get_permalink());
		$enroll=base64_decode($_GET['enroll']);
	session_start();
	$act_msg='';
	//$enroll=$_GET['enroll'];
	$userid=$_GET['img'];	
	$status='';
	$user_enroll='';
	global $wpdb;
	$result = $wpdb->get_results("select * from ".$wpdb->prefix."users where id='".$userid."'");
	foreach($result as $res){
		$status=$res->status;
		$user_enroll=$res->rand_number;
	}
	if($enroll==$user_enroll)
	{
	$succ=$wpdb->query(" UPDATE wp_users SET 
		status='1' where ID='".$userid."'");
			if($succ)
			{
				$_SESSION[success]="Your Account has Activate. Please login"; 
			}
			
	}
	?>
	<style>code{background:#ffffff;}</style>
	<script>
		var elements = document.getElementsByClassName('header-search');
		var string = document.getElementsByTagName("h1")[0].innerHTML;
        var replacedString = string.replace("Dashboard", "User Login");
        document.getElementsByTagName("h1")[0].innerHTML = replacedString;
		var newText = document.getElementsByClassName('current')[0];
		newText.innerHTML = 'User Login';
		while(elements.length > 0){
			elements[0].parentNode.removeChild(elements[0]);
		}
	</script>
	<section id="secondary-left" class="secondary-sidebar secondary-has-both-sidebar"><div  class='column dt-sc-one-third  space  first'    ></div></section>
		<section id="primary" class="page-with-sidebar page-with-both-sidebar">
			<fieldset style=" border: 1px solid #2e2989;">
			   <legend style="font-size:16px;color:#2e2989;">User Login</legend>
			     <?php echo '<b style="color:red;">'.$act_msg.'</b>';
			   if(isset($_SESSION[success])){
				echo '<b style="color:green;">'.$_SESSION["success"].'</b>';
				session_unset($_SESSION[success]);			
			   }
			   if(isset($_SESSION[message])){
			   echo '<b style="color:red;">'.$_SESSION["message"].'</b>';   
			   session_unset($_SESSION[message]);
			   }			
				?> 
	           <?php echo do_shortcode("[login_form]");?>
               <a href="<?=site_url('/dashboard/?ac=lostpass');?>">Forget Password?</a>		   
		    </fieldset>
		</section>
    <section id="secondary-right" class="secondary-sidebar secondary-has-both-sidebar"><div  class='column dt-sc-one-third  space  first'    ></div></section>
		<?php 
	}
	function Lostpassword(){ 
		$new_query = add_query_arg(array('ac' => 'lostpass'), get_permalink());
	?>
		<style>code{background:#ffffff;}</style>
		<script>
			var elements = document.getElementsByClassName('header-search');
			var string = document.getElementsByTagName("h1")[0].innerHTML;
				var replacedString = string.replace("Dashboard", "Forget Password");
				document.getElementsByTagName("h1")[0].innerHTML = replacedString;
				var newText = document.getElementsByClassName('current')[0];
				newText.innerHTML = 'Forget Password';
			while(elements.length > 0){
				elements[0].parentNode.removeChild(elements[0]);
			}
		</script>
	   <section id="secondary-left" class="secondary-sidebar secondary-has-both-sidebar"><div  class='column dt-sc-one-third  space  first'    ></div></section>
		<section id="primary" class="page-with-sidebar page-with-both-sidebar">
			<fieldset style=" border: 1px solid #2e2989;">
				<legend style="font-size:16px;color:#2e2989;">User Forgot Password</legend>
				<div class="tabdivinner-left" style="float:left; margin: 0px auto;">
					<div id="registration">
						<form method="post" action="<?php echo get_permalink($new_query); ?>" id="lostpasswordform" name="lostpasswordform">
							<p>
								<label for="user_login"><?php _e('Username or E-mail:'); ?><br>
								<input type="text" size="20" value="" class="input" id="user_login" name="user_login"></label>
							</p>
							<input type="hidden" value="" name="redirect_to">
							<p class="submit" style="margin-top: 15px;">
							
							<input type="submit" value="Get New Password" class="button button-primary button-large" id="wp-submit" name="wp-submit">
							<input type="button" value="Back" class="button button-primary button-large" name="back" onclick="javascript:window.history.back()">
							</p>
						</form>
					</div>
				</div>
				<div class="tabdivinner-right" style="float:left;"><img style="margin-left:60px;" height="187px" src="<?php echo IMGPATH; ?>forgot_left_icon.png" alt="Forgot Password" title="Forgot Password"></div>	
			</fieldset>
		</section>
	<section id="secondary-left" class="secondary-sidebar secondary-has-both-sidebar"><div  class='column dt-sc-one-third  space  first'    ></div></section>	
			
	<?php }
	
	function LoggedInUser(){
			if ( is_user_logged_in() ) {
		    $current=wp_get_current_user();
			if($current->status)
			{
			 $new_query = add_query_arg(array('ac' => 'dashboard'), get_permalink());		 
			wp_safe_redirect( $new_query);
			}else{
				wp_logout();
				session_start();
				$_SESSION["message"]="Your Account has not activated.Please check your Email";								
				$new_query = add_query_arg(array('ac' => 'login'), get_permalink());				
				wp_safe_redirect( $new_query);												
			}
			
		

		//	 $new_query = add_query_arg(array('ac' => 'dashboard'), get_permalink());

		//	wp_safe_redirect( $new_query);

			exit;

		}
	
	}
	function LoggedoutUser(){
		if ( !is_user_logged_in() ) {
			$new_query = add_query_arg(array('ac' => 'login'), get_permalink());
			wp_safe_redirect( $new_query);
			exit;
		}
	}
	
	
	function LoggedProcess(){
		if(isset($_POST['testcookie'])){
		global $wpdb;
		$username = $wpdb->escape($_REQUEST['log']);  
		$password = $wpdb->escape($_REQUEST['pwd']);  
		$rememberme = $wpdb->escape($_REQUEST['rememberme']);     
		if($remember) $remember = "true";  
		else $remember = "false";
		
			$user = wp_authenticate( $username, $password );
			if( is_wp_error( $user ) )
			{
				echo $error = $user->get_error_message();
				
			}else{
			
			$username		=	(isset($_POST['log'])) ? $_POST['log'] : '';
			$password		=	(isset($_POST['pwd'])) ? $_POST['pwd'] : '';
			$rememberme	=	(isset($_POST['rememberme'])) ? '1' : '0';
			
				$credentials = array();
				$credentials['user_login'] = $username;
				$credentials['user_password'] = $password;
				$credentials['remember'] = $rememberme;
				$user = wp_signon( $credentials, false );

				if ( is_wp_error( $user ) ) {
					echo $error = $user->get_error_message();
				} else {
					wp_set_current_user( $user->ID, $username );
					do_action('set_current_user');
					$new_query = add_query_arg(array('ac' => 'dashboard'), get_permalink());
					wp_safe_redirect( $new_query);
					
					exit; 
			}
		}
	}
	}
	
	function Dashboard(){ 
		
		MJdashboard::controls(); 
	
	}
	
	
	public static function controls(){ ?>
		<!--<div class="tabdivouter" style="width: 600px; margin: 0px auto;">
			<div class="tabdivinner" style="text-align: center; margin: 0px auto; width: 100%;">
			<fieldset style=" border: 1px solid;padding: 15px;">
			<legend>User Dashboard</legend>
				<table>
					<tr>
						<td style=" padding: 34px;">
							<div class="tabouter">
								<div class="tabinner-image"><a href="<?php echo wp_logout_url( LOGIN ); ?>"><img src="<?php echo IMGPATH; ?>logout.png" alt="Logout" title="Logout"></a></div>
								<div class="tabinner-label" style="text-align: center; margin-top: 21px;"><a title="Logout" href="<?php echo wp_logout_url( LOGIN ); ?>">Logout</a></div>
							</div>
						</td>
						<td style=" padding: 34px;">
							<div class="tabouter">
								<div class="tabinner-image"><a href="<?php echo PROFILE; ?>"><img src="<?php echo IMGPATH; ?>profile.png" alt="Profile" title="Profile"></a></div>
								<div class="tabinner-label" style="text-align: center; margin-top: 21px;"><a title="Profile" href="<?php echo PROFILE; ?>">Profile</a></div>
							</div>
						</td>
						<td style=" padding: 34px;">
							<div class="tabouter">
								<div class="tabinner-image"><a href="<?php echo PROFILEIMAGE; ?>"><?php MJdashboard::currentuserimage('123px'); ?></a></div>
								<div class="tabinner-label" style="text-align: center; margin-top: 21px;"><a title="profile-pic" href="<?php echo PROFILEIMAGE; ?>">profile-pic</a></div>
							</div>
						</td>
						
					</tr>
				</table>
				</fieldset>
			</div>
		</div>-->
		<style>code{background:#ffffff;}.tabcontent{margin:20px;}.imgcircle {
		  border-radius: 50%;
		  width:150px;
		  height:150px;
		}</style>
		<script>
			var elements = document.getElementsByClassName('header-search');
			while(elements.length > 0){
				elements[0].parentNode.removeChild(elements[0]);
			}
		</script>
		<?php
			global $current_user;
            get_currentuserinfo();
			   // echo "<pre>";
			   // echo $current_user->user_firstname;
			  // echo $current_user->roles[0];
			  // print_r($current_user);
			   // echo "</pre>";
		?>
		<section id="primary" class="content-full-width" style="border:8px solid #9fddeb;">
			 <div class="side-navigation">
				<div class="side-nav-container">
				    	<div class="dt-sc-ico-content type14" style="background: #f0f6f0;">
							<div class="dt-sc-timeline ">
							<?php 
								  $userID	=	get_current_user_id( );
								  $userdata = get_userdata($userID);
								  $image = basename($userdata->userphoto_thumb_file);
							?>
								<div class="custom-icon" ><a href="javascript:void(0)" onclick="openCity(event, 'Tokyo')">
								   <span class="fa fa-custom-icon1">
									   <?php 
											if($image){
												echo '<image class="imgcircle" src="'.PROFILEIMAGEDIR.'/userphoto/'.$image.' " title="Profile Image">';
											}else{
												echo '<image class="imgcircle" src="'.IMGPATH.'/no-avatar.png" title="No Profile Image">';
											}
									   ?>
								   </span></a>
								</div>
								<h4><a href="javascript:void(0)" target="_blank"><?php echo ucfirst($userdata->user_firstname).' '.ucfirst($userdata->user_lastname);?></a></h4>
							</div>
						</div>
					<ul class="side-nav">
						<li class="tablinks" onclick="openCity(event, 'London')" id="defaultOpen"><a href="javascript:void(0)" >Dashboard </a></li>
						<li class="tablinks" onclick="openCity(event, 'Paris')"><a href="javascript:void(0)" >Profile </a></li>
						<li class="tablinks" onclick="openCity(event, 'Kalmeshwar')"><a href="javascript:void(0)" >My Consultations </a></li>
						<?php $data = wp_get_current_user(); if($data->roles[0] == 'subscriber'){ ?>
						<li class="tablinks" onclick="openCity(event, 'Akola')"><a href="javascript:void(0)" >My Payment </a></li>
						<?php } ?>
						<?php $data = wp_get_current_user(); if($data->roles[0] === 'editor' || $data->roles[1] === 'editor'){ ?>
						<li class="tablinks" onclick="openCity(event, 'Shirdi')"><a href="javascript:void(0)" >Session Request </a></li>
						<?php } ?>
						<?php $data = wp_get_current_user(); if($data->roles[0] === 'editor' || $data->roles[1] === 'editor'){ ?>
						<li class="tablinks"><a href="<?=site_url('create-course');?>" >Topics </a></li>
						<?php } ?>
					</ul>
				</div>
			 </div>

			<div class="side-navigation-content"><!-- #post-1412 -->
				<div id="post-1412" class="post-1412 page type-page status-publish hentry">
				    <div class="dt-sc-timeline right ">
					   <div class="dt-sc-hr-invisible-medium  "></div>
					   <div class="dt-sc-hr-invisible-medium  "></div>
						<h2 class="border-title alignleft ">Welcome to <b style="color:#2e2989">MYUNI</b><span></span></h2>
						<?php session_start (); if(isset($_SESSION['success_pay'])){ ?>
								<script src="https://www.jquery-az.com/javascript/alert/dist/sweetalert.min.js"></script>
								<link rel="stylesheet" href="https://www.jquery-az.com/javascript/alert/dist/sweetalert.css">
									<script> swal("Your Payment Is Successfull.", "", "success"); </script>
									
						<?php unset($_SESSION['success_pay']);}?>
						<?php if(isset($_SESSION['error_pay'])){ ?>
								<script src="https://www.jquery-az.com/javascript/alert/dist/sweetalert.min.js"></script>
								<link rel="stylesheet" href="https://www.jquery-az.com/javascript/alert/dist/sweetalert.css">
									<script> swal("Your Payment Is Failed.!", "", "error"); </script>
						<?php unset($_SESSION['error_pay']);}?>
						
						<?php session_start (); if(isset($_SESSION['create_success'])){ ?>
								<script src="https://www.jquery-az.com/javascript/alert/dist/sweetalert.min.js"></script>
								<link rel="stylesheet" href="https://www.jquery-az.com/javascript/alert/dist/sweetalert.css">
									<script> swal("Your Consultation Is Created Successfully.", "", "success"); </script>
									
						<?php unset($_SESSION['create_success']);}?>
						<?php if(isset($_SESSION['create_error'])){ ?>
								<script src="https://www.jquery-az.com/javascript/alert/dist/sweetalert.min.js"></script>
								<link rel="stylesheet" href="https://www.jquery-az.com/javascript/alert/dist/sweetalert.css">
									<script> swal("Error: Your Consultations IS Created Unsuccess!", "", "error"); </script>
						<?php unset($_SESSION['create_error']);}?>
						<?php if(isset($_SESSION['cancel_pay'])){ ?>
								<script src="https://www.jquery-az.com/javascript/alert/dist/sweetalert.min.js"></script>
								<link rel="stylesheet" href="https://www.jquery-az.com/javascript/alert/dist/sweetalert.css">
								<script> swal("Cancel Your Payment Request!", "", "error"); </script>
						<?php unset($_SESSION['cancel_pay']);}?>
					</div>
					<p>
						<div id="London" class="tabcontent">
						  <p>Dear <?php echo $current_user->user_firstname.' '.$current_user->user_lastname.',';?></p>

                          <p>By filling more details about yourself, it becomes easier for a <?php if($current_user->roles[0] === 'editor' || $current_user->roles[1] === 'editor'){ echo 'Student'; }else{ echo 'Academic Experts'; }?> to know you and decide on selecting you. Please fill your complete profile and create your topic.</p>
						</div>

						<div id="Paris" class="tabcontent">
						   <?php echo do_shortcode("[profile-edit-dashboard]");?> 
						</div>
						
						<div id="India" class="tabcontent">
						   <?php echo do_shortcode("[WizIQ]");?> 
						</div>

						<div id="Tokyo" class="tabcontent">
						   <?php echo do_shortcode("[profile-dashboard]");?>
						</div>
						
						<div id="Kalmeshwar" class="tabcontent">
						   <?php echo do_shortcode("[users-myclass]");?>
						</div>
						
						<div id="Akola" class="tabcontent">
						   <?php echo do_shortcode("[users-mypayment]");?>
						</div>
						
						<div id="Shirdi" class="tabcontent">
						   <?php echo do_shortcode("[teacher-rqsession]");?>
						</div>
						
						<div id="Wakodi" class="tabcontent">
						   <?php echo do_shortcode("[teacher-crsession]");?>
						</div>
					</p>
					<div class="social-bookmark"></div><div class="social-share"></div>	
				</div><!-- #post-1412 -->
			</div>  
		</section>
		<script>
		function openCity(evt, cityName) {
			var i, tabcontent, tablinks;
			tabcontent = document.getElementsByClassName("tabcontent");
			for (i = 0; i < tabcontent.length; i++) {
				tabcontent[i].style.display = "none";
			}
			tablinks = document.getElementsByClassName("tablinks");
			for (i = 0; i < tablinks.length; i++) {
				tablinks[i].className = tablinks[i].className.replace(" current_page_item", "");
			}
			document.getElementById(cityName).style.display = "block";
			evt.currentTarget.className += " current_page_item";
			jQuery('#actiontd').trigger('click');
			jQuery('#actionpay').trigger('click');
			jQuery('#actionbook').trigger('click');
		}

		// Get the element with id="defaultOpen" and click on it
		document.getElementById("defaultOpen").click();
		</script>
		
	<?php }
	function Imageupload(){ ?>
		<section id="primary" class="content-full-width">
	    <section id="secondary-left" class="secondary-sidebar secondary-has-both-sidebar"><div  class='column dt-sc-one-third  space  first'    ></div></section>
		    <section id="primary" class="page-with-sidebar page-with-both-sidebar">
				<fieldset class="content-full-width" style=" border: 1px solid #2e2989;">
				<legend style="font-size:14px;color:#2e2989;">Upload Profile Image</legend>
					<?php MJdashboard::currentuserimage(); ?>
					<form class="content-full-width" name="profile" id="your-profile" action="<?php echo PROFILEIMAGE; ?>" method="post" enctype="multipart/form-data">
					<table>
						<tr>
							<td>
								Upload Image : 
							</td>
							<td>
								<input type="file" name="file" id="file">
							</td>
						</tr>
						<tr>
							<td align="right" colspan="2">
								<p class="submit" style="margin-top: 15px;">
								<input type="submit" value="upload Image" class="button button-primary button-large" id="wp-submit" name="wp-submit">
								<!--<input type="button" value="Back" class="button button-primary button-large" name="back" onclick="javascript:window.history.back()">-->
								</p>
							</td>
							
						</tr>
					</table>
					</form>
				</fieldset>
			</section>
		</section>
		
	<?php }
	public static function currentuserimage($height='100px'){
		$userID	=	get_current_user_id( );
		$userdata = get_userdata($userID);
		$image = basename($userdata->userphoto_thumb_file);
		echo "<div class='imagediv center'>";
		if($image){
			echo '<image src="'.PROFILEIMAGEDIR.'/userphoto/'.$image.' " height="'.$height.'" title="Profile Image">';
		}else{
			echo '<image src="'.IMGPATH.'/no-avatar.png" height="'.$height.'" title="No Profile Image">';
		}
		echo "</div>";
	}
	
	public static function imageprocess(){
		$userID	=	get_current_user_id( );
		$userphoto_validtypes = array(
			"image/jpeg" => true,
			"image/pjpeg" => true,
			"image/gif" => true,
			"image/png" => true,
			"image/x-png" => true
		);
		$userphoto_validextensions = array('jpeg', 'jpg', 'gif', 'png');

		if(isset($_FILES['file']) && @$_FILES['file']['name']){
			
			#Upload error
			if( !$_FILES['file']['size'] ){
				echo  sprintf(__("The file &ldquo;%s&rdquo; was not uploaded. Did you provide the correct filename?", 'user-photo'), $_FILES['file']['name']);
			}
			else if( !preg_match("/.(" . join('|', $userphoto_validextensions) . ")$/i", $_FILES['file']['name']) ){
				echo sprintf(__("The file extension &ldquo;%s&rdquo; is not allowed. Must be one of: %s.", 'user-photo'), preg_replace('/.*./', '', $_FILES['file']['name']), join(', ', $userphoto_validextensions));
			}
			else if( @!$userphoto_validtypes[$_FILES['file']['type']] ){
				echo sprintf(__("The uploaded file type &ldquo;%s&rdquo; is not allowed.", 'user-photo'), $_FILES['file']['type']);
			}else{
				$tmppath = $_FILES['file']['tmp_name'];
				
				$imageinfo = null;
				$thumbinfo = null;
				$upload_dir = wp_upload_dir();
				$dir = trailingslashit($upload_dir['basedir']) . 'userphoto';
				
				#$umask = umask(0);
				if(!file_exists($dir) && @!mkdir($dir, 0777))
					echo sprintf(__("The userphoto upload content directory does not exist and could not be created. Please ensure that you have write permissions for the '%s' directory. Did you put slash at the beginning of the upload path in Misc. settings? It should be a path relative to the WordPress root directory. <code>wp_upload_dir()</code> returned:<br /> <code style='white-space:pre'>%s</code>", 'user-photo'), $dir, print_r($upload_dir, true));
				#umask($umask);
				
				if(!$error){
					$userdata = get_userdata($userID);
					$oldimagefile = basename($userdata->userphoto_image_file);
					$imagefile = "$userID." . preg_replace('{^.+?.(?=w+$)}', '', strtolower($_FILES['file']['name']));
					$imagepath = $dir . '/' . $imagefile;
					$thumbfile = preg_replace("/(?=.w+$)/", '', $imagefile);
					$thumbpath = $dir . '/' . $thumbfile;
					
					if(!move_uploaded_file($tmppath, $imagepath)){
						$error = sprintf(__("Unable to place the user photo at: %s", 'user-photo'), $imagepath);
					}
					
						
						update_usermeta($userID, "userphoto_thumb_file", $thumbfile);
						echo "Image uploaded successfully";
						wp_redirect(site_url('dashboard'));
						
						//Delete old thumbnail if it has a different filename (extension)
						 if($oldimagefile != $imagefile)
							@unlink($dir . '/' . $oldimagefile);
						if($oldthumbfile != $thumbfile)
							@unlink($dir . '/' . $oldthumbfile); 
					}
				}
			}
		}
	
	public static function Logincontrols(){   ?>
		<style>code{background:#ffffff;}</style>
		<script>
			var elements = document.getElementsByClassName('header-search');
			var string = document.getElementsByTagName("h1")[0].innerHTML;
			var replacedString = string.replace("Dashboard", "User Login");
			document.getElementsByTagName("h1")[0].innerHTML = replacedString;
			var newText = document.getElementsByClassName('current')[0];
			newText.innerHTML = 'User Login';
			while(elements.length > 0){
				elements[0].parentNode.removeChild(elements[0]);
			}
		</script>
		<section id="secondary-left" class="secondary-sidebar secondary-has-both-sidebar"><div  class='column dt-sc-one-third  space  first'    ></div></section>
			<section id="primary" class="page-with-sidebar page-with-both-sidebar">
				<fieldset style=" border: 1px solid #2e2989;">
				   <legend style="font-size:16px;color:#2e2989;">User Login</legend>
				   <?php echo do_shortcode("[login_form]");?>
				   <a href="<?=site_url('/dashboard/?ac=lostpass');?>">Forget Password?</a>		   
				</fieldset>
			</section>
		<section id="secondary-right" class="secondary-sidebar secondary-has-both-sidebar"><div  class='column dt-sc-one-third  space  first'    ></div></section>
	<?php }
	
	function PassProcess(){
		if(isset($_POST['user_login'])){
			
				$email	=	(isset($_REQUEST['user_login'])) ? $_REQUEST['user_login'] : ''; 
				if (empty($email) || !is_email($email)) {
					echo 'Not A Valid Email address';
				}else if ( !email_exists($email) ){
					echo 'Email address not exist';
				}else{
					MJdashboard::SetPassword($email);
				}
				
		}
	}
	
	function SetPassword($email){
		$user = get_user_by('email', $email);
		$newpass	=	wp_generate_password();
		$name	=	$user->first_name .' '. $user->last_name;
		wp_set_password( $newpass, $user->ID );
		MJdashboard::Passwordmail($email,$name,$newpass);
	}
	     
	function Passwordmail($email,$name,$newpass){
		$blog_title = get_bloginfo('name'); 
		$admin_email = get_bloginfo('admin_email'); 
		add_filter('wp_mail_content_type',create_function('', 'return "text/html";'));
		$headers = 'From: My Name <'.$admin_email.'>' . "rn";
		$message	=
		"hello $name,
		<p>We have reset your password here is your new password please check it</p>
		<p>======================================================================</p>
		<p>New Password : $newpass</p>
		<p>======================================================================</p>
		<p>For more details please contact to administrator</p>
		<p>Thanks & Regards<br/>$blog_title</p>
		<br/>";
		$sent	=	wp_mail($email, 'New Password', $message, $headers);
		if($sent){
			echo "New Password Sent on you `$email` mail address.";
		}else{
			echo "Error while sending mail. Please try it later.";
		}
	}
	
	function Registration(){ 
	$new_query = add_query_arg(array('ac' => 'registration'), get_permalink());
	$role_stud='student';
	$role_teac='teacher';
	$get_role=$_GET[role];
		 			
	?>
	        <style>code{background:#ffffff;}</style>
			<script>
				var elements = document.getElementsByClassName('header-search');
				var string = document.getElementsByTagName("h1")[0].innerHTML;
				var replacedString = string.replace("Dashboard", "User Registration");
				document.getElementsByTagName("h1")[0].innerHTML = replacedString;
				var newText = document.getElementsByClassName('current')[0];
				newText.innerHTML = 'User Registration';
				while(elements.length > 0){
					elements[0].parentNode.removeChild(elements[0]);
				}
			</script>
			<section id="secondary-left" class="secondary-sidebar secondary-has-both-sidebar"><div  class='column dt-sc-one-third  space  first'    ></div></section>
			<section id="primary" class="page-with-sidebar page-with-both-sidebar">
			<fieldset style=" border: 1px solid #2e2989;">
				<legend style="font-size:16px;color:#2e2989;"><?php if($role_stud===$get_role){echo ucfirst($_GET[role]); } ?>
				<?php if($role_teac===$get_role){echo 'Academic Experts'; } ?>
				Registration</legend>
					<?php echo do_shortcode("[cr_custom_registration]");?>
				</fieldset>
			</section>
			<section id="secondary-right" class="secondary-sidebar secondary-has-both-sidebar"><div  class='column dt-sc-one-third  space  first'    ></div></section>
<?php
}

	function RegProcess(){
	
		if($_POST['wp-submit']){
			global $wpdb;
			$email = $wpdb->escape($_REQUEST['email']);
			$username = $wpdb->escape($_REQUEST['username']);
			if(empty($username)) {
				echo "User name should not be empty.";
			}else if(!preg_match("/^[_a-z0-9-]+(.[_a-z0-9-]+)*@[a-z0-9-]+(.[a-z0-9-]+)*(.[a-z]{2,4})$/", $email)) {
				echo "Please enter a valid email.";
			}else{
					$random_password = wp_generate_password( 12, false );
					$status = wp_create_user( $username, $random_password, $email );
					if ( is_wp_error($status) ){
						echo $error = $status->get_error_message();
					}else {
						$from = get_option('admin_email');
						$headers = 'From: '.$from . "rn";
						$subject = "Registration successful";
						echo $msg = "Registration successful.nYour login detailsnUsername: $usernamenPassword: $random_password";
						wp_mail( $email, $subject, $msg, $headers );
						echo "Please check your email for login details.";
					}
				}
		}
	}
	
	function profile(){ 
	global $current_user, $wp_roles;
$new_query = add_query_arg(array('ac' => 'profile'), get_permalink());

	?>
		<div class="entry-content entry">
            <?php if ( !is_user_logged_in() ) : ?>
                    <p class="warning">
                        <?php _e('You must be logged in to edit your profile.', 'profile'); ?>
                    </p><!-- .warning -->
            <?php else : ?>
                <?php if ( count($error) > 0 ) echo '<p class="error">' . implode("<br />", $error) . '</p>'; ?>
			
					<form method="post" id="adduser" action="<?php echo get_permalink($new_query);?>">
                    <p class="form-username">
                        <label for="first-name"><?php _e('First Name', 'profile'); ?></label>
                        <input class="text-input" name="first-name" type="text" id="first-name" value="<?php the_author_meta( 'user_firstname', $current_user->id ); ?>" />
                    </p><!-- .form-username -->
                    <p class="form-username">
                        <label for="last-name"><?php _e('Last Name', 'profile'); ?></label>
                        <input class="text-input" name="last-name" type="text" id="last-name" value="<?php the_author_meta( 'user_lastname', $current_user->id ); ?>" />
                    </p><!-- .form-username -->
					<!--<p class="form-nickname">
                        <label for="nick-name"><?php _e('Nick Name', 'profile'); ?></label>
                        <input class="text-input" name="nickname" type="text" id="nickname" value="<?php echo $current_user->user_nicename ?>" />
                    </p>--><!-- .form-username -->
                    <p class="form-email">
                        <label for="email"><?php _e('E-mail *', 'profile'); ?></label>
                        <input class="text-input" name="email" type="text" id="email" value="<?php the_author_meta( 'user_email', $current_user->id ); ?>" />
                    </p><!-- .form-email -->
                    <?php 
					if(!$current_user->wp_capabilities[subscriber]):
					?>
					<p class="form-email">
                        <label for="exp"><?php _e('Experience *', 'profile'); ?></label>
                        <input class="text-input" min="0" max="50" name="exp" type="number" id="exp" required value="<?php the_author_meta( 'user_exp', $current_user->id ); ?>" />
                    </p><!-- .form-exp -->
					<script>
					var lang=[];	
					function show(){
					var getlang=document.getElementById('languages').value;	
					lang.push(getlang)
					lang=removeDuplicateUsingFilter(lang);
					var select=lang.toString();	
					document.getElementById('user_consult_lang').value = select;
					}
					function removeDuplicateUsingFilter(arr){
					var unique_array = arr.filter(function(elem, index, self) {
					return index == self.indexOf(elem);
						});
						return unique_array
					}
							
				</script>	
					<p class="form-email">
					<label class="label_reg" for="Languages">Language</label>
					<select class="input" onchange="show()" id="languages" name="Languages">
					<option value="languages">Select Language</option> ';
						<?php global $wpdb;		
						$result = $wpdb->get_results("select * from ".$wpdb->prefix ."languages");
						if(!empty($result))
						{
							foreach($result as $re)
							{
								echo '<option value="'.$re->name.'" >'.$re->name.'</option>';
							}
						}		
					   ?> 
					</select>
					</p>
							
					<p class="form-email">
					<label for="user_consult_lang"><?php _e('Language I can consult', 'profile'); ?></label>
                    <input class="text-input" readonly name="user_consult_lang" type="text" id="user_consult_lang" required value="<?php the_author_meta( 'user_lang', $current_user->id ); ?>" />
					</p>
					<p class="form-email">
                        <label for="universities"><?php _e('Universities ', 'profile'); ?></label>
                        <input class="text-input" name="universities" type="text" id="universities" value="<?php the_author_meta( 'universities', $current_user->id ); ?>" />
                    </p><!-- .form-universities -->
					<p class="form-email">
						<label for="Degrees"><?php _e('Degrees ', 'profile'); ?></label></br>
						<?php $selected="checked" ;$check_list=array(); if(true){$check_list=explode(',',$current_user->degrees,5);
						$res='<input type="radio" name="check_list[]"  '.(($check_list[0]==="Bachelor") ? $selected: null).' value="Bachelor"/>&nbsp;&nbsp;Bachelor&nbsp;&nbsp;
						<input type="radio" name="check_list[]"  '.(($check_list[0]==="Master") ? $selected: null).' value="Master"/>&nbsp;&nbsp;Master&nbsp;&nbsp;
						<input type="radio" name="check_list[]"  '.(($check_list[0]==="PHD") ? $selected: null).' value="PHD"/>&nbsp;&nbsp;PHD&nbsp;&nbsp;
						<input type="radio" name="check_list[]"  '.(($check_list[0]==="Professor") ? $selected: null).' value="Professor"/>&nbsp;&nbsp;Professor&nbsp;&nbsp;';
					echo $res; 
						}?>
					</p>
					<!--<p class="form-username">
                        <label for="display-name"><?php _e('Display Name', 'profile'); ?></label>
                        <input class="text-input" name="display-name" type="text" id="display-name" value="<?php the_author_meta( 'display_name', $current_user->id ); ?>" />
                    </p>--><!-- .form-displayname -->
					<?php endif;?>
                    <!--<p class="form-url">
                        <label for="url"><?php _e('Website', 'profile'); ?></label>
                        <input class="text-input" name="url" type="text" id="url" value="<?php the_author_meta( 'user_url', $current_user->id ); ?>" />
                    </p>--><!-- .form-url -->
					<!--<p class="form-url">
                        <label for="url"><?php _e('AIM', 'profile'); ?></label>
                        <input class="text-input" name="aim" type="text" id="aim" value="<?php the_author_meta( 'aim', $current_user->id ); ?>" />
                    </p>-->
					<!--<p class="form-url">
                        <label for="url"><?php _e('Yahoo IM', 'profile'); ?></label>
                        <input class="text-input" name="yim" type="text" id="yim" value="<?php the_author_meta( 'yim', $current_user->id ); ?>" />
                    </p>
					<p class="form-url">
                        <label for="url"><?php _e('Jabber / Google Talk', 'profile'); ?></label>
                        <input class="text-input" name="jabber" type="text" id="jabber" value="<?php the_author_meta( 'jabber', $current_user->id ); ?>" />
                    </p>--><!-- .form-url -->
                    <p class="form-password">
                        <label for="pass1"><?php _e('Password *', 'profile'); ?> </label>
                        <input class="text-input" name="pass1" type="password" id="pass1" />
                    </p><!-- .form-password -->
                    <p class="form-password">
                        <label for="pass2"><?php _e('Repeat Password *', 'profile'); ?></label>
                        <input class="text-input" name="pass2" type="password" id="pass2" />
                    </p><!-- .form-password -->
                    <p class="form-textarea">
                        <label for="description"><?php _e('Biographical Information', 'profile') ?></label>
                        <textarea name="description" id="description" rows="3" cols="50"><?php the_author_meta( 'description', $current_user->id ); ?></textarea>
                    </p><!-- .form-textarea -->

                    <?php 
                        //action hook for plugin and extra fields
                        do_action('edit_user_profile',$current_user); 
                    ?>
                    <p class="form-submit">
                        <?php echo $referer; ?>
                        <input name="updateuser" type="submit" id="updateuser" class="submit button" value="<?php _e('Update', 'profile'); ?>" />
						<!--<input type="button" value="Back" class="button button-primary button-large" name="back" onclick="javascript:window.history.back()">-->
                        <?php wp_nonce_field( 'update-user' ) ?>
                        <input name="action" type="hidden" id="action" value="update-user" />
                    </p><!-- .form-submit -->
                </form><!-- #adduser -->
            <?php endif; ?>
        </div><!-- .entry-content --> 
	<?php
	}
	
	function ProProcess(){
		global $current_user, $wp_roles;
		get_currentuserinfo();

		/* Load the registration file. */
		require_once( ABSPATH . WPINC . '/registration.php' );
		$error = array();    
		/* If profile was saved, update profile. */
		if ( 'POST' == $_SERVER['REQUEST_METHOD'] && !empty( $_POST['action'] ) && $_POST['action'] == 'update-user' ) {

			/* Update user password. */
			if ( !empty($_POST['pass1'] ) && !empty( $_POST['pass2'] ) ) {
				if ( $_POST['pass1'] == $_POST['pass2'] )
					wp_update_user( array( 'ID' => $current_user->id, 'user_pass' => esc_attr( $_POST['pass1'] ) ) );
				else
					$error[] = __('The passwords you entered do not match.  Your password was not updated.', 'profile');
			}

			/* Update user information. */
			
			if ( !empty( $_POST['email'] ) ){
				if (!is_email(esc_attr( $_POST['email'] )))
					$error[] = __('The Email you entered is no valid.  please try again.', 'profile');
				elseif(email_exists(esc_attr( $_POST['email'] )) != $current_user->id )
					$error[] = __('This email is allready used by another user.  try a different one.', 'profile');
				else{
					wp_update_user( array ('ID' => $current_user->id, 'user_email' => esc_attr( $_POST['email'] )));
				}
			}
			
			if ( !empty( $_POST['nickname'] ) ){
					wp_update_user( array ('ID' => $current_user->id, 'user_nicename' => esc_attr( $_POST['nickname'] )));
			}
			
			if ( !empty( $_POST['url'] ) ){
				update_usermeta( $current_user->id, 'user_url', esc_url( $_POST['url'] ) );
			}
			if ( !empty( $_POST['exp'] ) ){
				global $wpdb;   
				$wpdb->query( "
						UPDATE wp_users 
						SET user_exp = '".$_POST['exp']."' 
						WHERE ID = '".$current_user->id."'"
						);
				}	
			if ( !empty( $_POST['check_list'] ) ){
				global $wpdb;   
				$wpdb->query( "
						UPDATE wp_users 
						SET degrees = '".implode(",",$_POST['check_list'])."' 
						WHERE ID = '".$current_user->id."'"
						);
				}					
				if ( !empty( $_POST['user_consult_lang'] ) ){
				global $wpdb;   
				$wpdb->query( "
						UPDATE wp_users 
						SET user_lang = '".$_POST['user_consult_lang']."' 
						WHERE ID = '".$current_user->id."'"
						);
				}
			if(!empty($_POST['universities']))
			    {
				global $wpdb;   
				$wpdb->query( "
						UPDATE wp_users 
						SET universities = '".$_POST['universities']."' 
						WHERE ID = '".$current_user->id."'"
						);
			    }
			if(!empty($_POST['first-name']))
				{
					global $wpdb;
					$display = $_POST['first-name'].' '.$_POST['last-name'];
					$wpdb->query("UPDATE wp_users SET display_name ='".$display."'
					WHERE ID = '".$current_user->id."'");
				}
				
			if ( !empty( $_POST['first-name'] ) )
				update_usermeta( $current_user->id, 'first_name', esc_attr( $_POST['first-name'] ) );
			if ( !empty( $_POST['last-name'] ) )
				update_usermeta($current_user->id, 'last_name', esc_attr( $_POST['last-name'] ) );
			if ( !empty( $_POST['description'] ) )
				update_usermeta($current_user->id, 'description', esc_attr( $_POST['description'] ) );
			if ( !empty( $_POST['aim'] ) )
				update_usermeta( $current_user->id, 'aim', esc_attr( $_POST['aim'] ) );
			if ( !empty( $_POST['yim'] ) )
				update_usermeta( $current_user->id, 'yim', esc_attr( $_POST['yim'] ) );
			if ( !empty( $_POST['jabber'] ) )
				update_usermeta( $current_user->id, 'jabber', esc_attr( $_POST['jabber'] ) );

			/* Redirect so the page will show updated info. */
			 if ( count($error) == 0 ) {
				//action hook for plugins and extra fields saving
				do_action('edit_user_profile_update', $current_user->id);
				//wp_redirect( get_permalink() );
				//exit;
				_e('<script>alert("Profile Update Successfully");</script><p style="font-size:14px;color:Green;">Profile Update Successfully</p>');
				
			} 
		}
	} 
	function Myclasses(){ ?>
	 <link href="https://cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css" rel="stylesheet"  />
		<!-- Here goes your custom content -->
		   <?php $data = wp_get_current_user();
		   //print_r($data);
       if($data->roles[0] === 'subscriber'){ ?>
	   <article id="post-1234565" >
		<div class="entry-content table-responsive">
			<table id="example2" class="display" cellspacing="0" width="100%">
			<thead>
				<tr>
					<th>Consultations</th>
					<th>Date/ Time</th>
					<th>Duration</th>
					<th>Academic Experts</th>
					<th id="actiontd">Action</th>
				</tr>
			</thead>
			<tbody>
			<?php global $wpdb;
			  $result = $wpdb->get_results("select * from ".$wpdb->prefix ."wiziq_wclasses_student JOIN ".$wpdb->prefix ."wiziq_wclasses where (".$wpdb->prefix ."wiziq_wclasses_student.class_id = ".$wpdb->prefix ."wiziq_wclasses.response_class_id) and (".$wpdb->prefix ."wiziq_wclasses_student.user_id =".$data->ID.")");
			 foreach($result as $key => $value) { ?>
				<tr>
					<td><?= $value->class_name; ?></td>
					<td><?php 
						$zonedatestart = date( 'Y-m-d H:i:s', strtotime($value->class_time));
					    echo date('d-m-Y H:i A' , strtotime($zonedatestart)); ?>
					</td>
					<td><?= $value->duration; ?> (Mins)</td>
					<td><?php $user = get_userdata($value->created_by); echo $user->user_firstname.' '; echo$user->user_lastname;?></td>
					<?php if( date('Y-m-d') <= date('Y-m-d' , strtotime($value->class_time)) ) { ?>
					<td><a href="<?= $value->response_attendee_url; ?>" class="dt-sc-button small" target='_blank'>ENTER CONSULTATIONS</a></td>
					<?php } else { ?>
				    <td><a href="<?= $value->response_recording_url; ?>" target='_blank' class="dt-sc-button small">View Recording</a></td>
					<?php } ?>
				</tr>
			<?php } ?>
			</tbody>
			</table>
			</div>
			</article>
      <?php } elseif($data->roles[0] === 'editor' || $data->roles[1] === 'editor'){ ?>	
		   <article id="post-1234565" >
			<div class="entry-content table-responsive">	  
			  <table id="example3" class="display nowrap" cellspacing="0" width="100%">
				<thead>
					<tr>
						<th>Consultations</th>
						<th>Date/ Time</th>
						<th>Duration</th>
						<th>Student Name</th>
						<th id="actiontd">Action</th>
					</tr>
				</thead>
				<tbody>
				<?php global $wpdb;
				  $result = $wpdb->get_results("select * from ".$wpdb->prefix ."wiziq_wclasses where created_by = '".$data->ID."'");
				  foreach($result as $key => $value) { ?>
								<tr>
									<td><?= $value->class_name; ?>
									</td>
									<td><?= date('d-m-Y H:i A' , strtotime($value->class_time)); ?></td>
									 <td><?= $value->duration; ?> (Mins)</td>
									 <td><?php
									  global $wpdb;
										$classstudent = $wpdb->get_results("select user_id from ".$wpdb->prefix ."wiziq_wclasses_student where class_id = ".$value->response_class_id);
										$stupiduser = get_userdata($classstudent[0]->user_id); 
										echo $stupiduser->user_firstname.' '. $stupiduser->user_lastname;
									 ?></td>
									<?php if( date('Y-m-d') <= date('Y-m-d' , strtotime($value->class_time)) ) { ?>
									<td><a href="<?= $value->response_presenter_url ?>" target='_blank' class="dt-sc-button small">ENTER CONSULTATIONS</a></td>
									<?php } else { ?>
									 <td><a href="<?= $value->response_recording_url ?>" target='_blank' class="dt-sc-button small">View Recording</a></td>
									<?php } ?>
								</tr>
							<?php } ?>
				</tbody>
				</table>
				</div>
			</article>
		<?php } ?>					
	
<script type="text/javascript" src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
<script type="text/javascript">
var j = jQuery ;
  j(document).ready(function() {
    j('#example2').DataTable({  "scrollX": true});
  });
</script>
<script type="text/javascript">
var j = jQuery ;
  j(document).ready(function() {
    j('#example3').DataTable({  "scrollX": true});
  });
</script>
<?php } function Mypayment(){ ?>
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css">
	<div class="wrap">
		<!--<h2>Payment Details</h2>-->
	</div>
	<article id="post-1234565" >
	    <h2>Payment Details</h2>
		<div class="entry-content">
			<table id="example23" class="display" cellspacing="0" width="100%">
			<thead>
				<tr>
				    <th>Sr No</th>
					<th>Topic Name</th>
					<th>Txn ID</th>
					<th>Date</th>
					<th>Payment Gross</th>
					<th>Currency Code</th>
					<th id="actionpay">Payment Status</th>
					
				</tr>
			</thead>
			<tbody>
			<?php 
			  global $wpdb;
			  $data = wp_get_current_user();
			  $srno = 1;
			  $result = $wpdb->get_results("select * from ".$wpdb->prefix ."payments where user_id=".$data->ID);
			 foreach($result as $key => $value) { ?>
				<tr>
				    <td><?= $srno;?></td>
					<td><?php $course = $wpdb->get_results("select * from ".$wpdb->prefix ."wiziq_courses where id='".$value->item_number."'"); 
					foreach($course as $key => $cvalue) echo $cvalue->fullname; ?></td>
					<td><?= $value->txn_id; ?></td>
					<td><?= date('d F Y',strtotime($value->payment_date));?></td>
					<td>$<?= $value->payment_gross; ?></td>
					<td><?= $value->currency_code; ?></td>
					<td><?= $value->payment_status; ?></td>
				</tr>
			<?php $srno++;} ?>
			</tbody>
			</table>
		</div><!-- .entry-content -->
	</article><!-- #post-## -->
	<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.3.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript">
	var j = jQuery ;
	  j(document).ready(function() {
		j('#example23').DataTable({  "scrollX": true});
	  });
	</script>
<?php }  function Rqsession(){ ?>
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css">
	<div class="wrap">
		<!--<h2>Payment Details</h2>-->
	</div>
	<article id="post-1234565" >
	    <h2>Book Requested Session</h2>
		<div class="entry-content">
			<table id="example34234" class="display" cellspacing="0" width="100%">
			<thead>
				<tr>
				    <th>Sr No</th>
					<th>Request By</th>
					<th>Topic Name</th>
					<th>Date</th>
					<th>Time</th>
					<th>Duration</th>
					<th>Timzone</th>
					<th>Price</th>	
                    <th id="actionbook">Action</th>						
				</tr>
			</thead>
			<tbody>
			<?php 
			  global $wpdb;
			  $data = wp_get_current_user();
			  $srno = 1;
			  $result = $wpdb->get_results("select * from ".$wpdb->prefix ."trial_session where teacher_id='".$data->ID."' and status = 0");
			 foreach($result as $key => $value) { ?>
				<tr>
				    <td><?= $srno;?></td>
					<td><?php $userinfo = get_userdata($value->user_id); echo $userinfo->display_name;?></td>
					<td><?php $course = $wpdb->get_results("select * from ".$wpdb->prefix ."wiziq_courses where id='".$value->course_id."'"); 
					foreach($course as $key => $cvalue) echo $cvalue->fullname; ?></td>
					<td><?= date('d F Y',strtotime($value->class_date));?></td>
					<td><?= date('H:i:s',strtotime($value->class_time));?></td>
					<td><?= $value->duration; ?> min</td>
					<td><?= $value->timezone; ?></td>
					<td>$<?= $value->price; ?></td>
					<td><?php $hash = base64_encode($value->id);?><a href="<?=site_url('dashboard/?ac=createsession&para='.$value->id); ?>" class="dt-sc-button small" >Accept</a>
					</td>
				</tr>
			<?php $srno++;} ?>
			</tbody>
			</table>
		</div><!-- .entry-content -->
	</article><!-- #post-## -->
	<script>
	/*$(function(){
		$("a#counter<?=$srno?>").click(function()
		{
			 if (history.pushState) {
				  var newurl = window.location.protocol + "//" + window.location.host + window.location.pathname + '?para=<?=$value->id?>';
				  window.history.pushState({path:newurl},'',newurl);
			  }
		});
	});*/
	</script>
	<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.3.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript">
	var j = jQuery ;
	  j(document).ready(function() {
		j('#example34234').DataTable({  "scrollX": true});
	  });
	</script>
<?php } function Crsession(){ ?>

<?php 
	  global $wpdb;
	  $data = wp_get_current_user();
	  $srno = 1;
	  $result = $wpdb->get_results("select * from ".$wpdb->prefix ."trial_session where teacher_id=".$data->ID." and id='".$_GET['para']."' and status = 0");
	 foreach($result as $key => $value) $userinfo = get_userdata($value->user_id); ?>
<!-- ** Primary Section ** -->
	<div class="fullwidth-section  " style="padding-bottom:60px;">	<div class="container"><div class="column dt-sc-two-third  space  first"><h5 class="border-title  ">Create Consultations<span></span></h5>
		<div role="form" class="" id="" lang="en-US" dir="">
		<div class="screen-reader-response"></div>
		<form action="<?php echo site_url('/requestsession.php'); ?>" method="POST" class="" >
		<div id="contact-form">
		<span><b>Requested By</b></span>
		<p>
		<input type="hidden" name="user_id" value="<?=$value->user_id;?>"/>
		<span class="wpcf7-form-control-wrap your-name"><input readonly type="text" name="username"  size="40" value="<?=$userinfo->display_name;?>"></span>
		</p>
		<span><b>Consultations Name</b></span>
		<p>
		<?php $course = $wpdb->get_results("select * from ".$wpdb->prefix ."wiziq_courses where id='".$value->course_id."'"); 
					foreach($course as $key => $cvalue); ?>
					<input type="hidden" name="para" value="<?=$value->id;?>"/>
					<input type="hidden" name="created_by" value="<?=$value->teacher_id;?>"/>
					<input type="hidden" name="course_id" value="<?=$value->course_id;?>"/>
		<span class="wpcf7-form-control-wrap your-email"><input type="text" name="class_name" value="<?=$cvalue->fullname?>" size="40" required ></span>
		</p>
		<span><b>Consultations Date</b></span>
		<p>
		<span class="wpcf7-form-control-wrap calendar"><input id="datepickerm" name="batch_date" value="<?=date('m/d/Y',strtotime($value->class_date));?>" placeholder="Select Date" type="text" required></span>
		</p>
		<span><b>Consultations Time</b></span>
		<p>
		<span class="wpcf7-form-control-wrap calendar"><input class="timepicker" id="timepicker1" type="text" value="<?=date('H:i',strtotime($value->class_time));?>" name="class_time" placeholder="Select Time" required></span>
		</p>
		<span><b>Consultations TimeZone</b></span>
        <p>
			<select id="class_timezone" name="india">
			 <option>Your Session Timezone</option>
			<?php
				$wiziq_api_functions = new wiziq_api_functions; 
				$timezone = $wiziq_api_functions->getTimeZone();
				foreach ($timezone as $key => $values) {
				?>
					<option value = "<?php echo $key; ?>" <?php if( $value->timezone === $key ) echo ' selected'; ?> ><?php echo $values; ?></option>
				<?php 
				}
				?>
			</select>									
		</p>
		<span><b>Duration</b></span>
		<p>
			<select id="interval" name="duration"><option label="Select" >Select</option><option value="30" <?php if( $value->duration == 30 ) echo ' selected'; ?>>30 min</option>
				<option value="60" <?php if( $value->duration == 60 ) echo ' selected'; ?>>1 hour</option>
				<option value="90" <?php if( $value->duration == 90 ) echo ' selected'; ?>>90 min</option>
				<option value="120" <?php if( $value->duration == 120 ) echo ' selected'; ?>>2 hour</option>
			</select>
		</p>
        <input type="submit" value="Create Consultations" class="" name="submit-class">
	    </div>
		</form>
		</div>
		</div>
		</div>
		</div>
		<script type="text/javascript">
			var j = jQuery ;
			j( function() {
				j('#timepicker1').timepicker({
					 showInputs: false,
					 timeFormat: 'HH:mm',
				});
				
			 });
			</script>
	 <script>
			var j = jQuery ;
			  var today = new Date();
			  j( function() {
				j( "#datepickerm" ).datepicker({
				dateFormat: 'mm/dd/yy',
				minDate: today
			});
			 j('.post-edit-link').remove();
			});
	 </script>	
 
<?php }
}
?>