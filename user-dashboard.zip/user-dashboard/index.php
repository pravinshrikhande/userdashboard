<?php
/*
Plugin Name: User-Dashboard
Plugin URI: http://mecontact.wordpress.com/user-dashboard/
Description: User-Dashboard include the option with login, registration and forget password from front-end also provide you the option to logged out profile editing and image uploading for profile . it provides you proper dashboard from front end user to add more options and edit html easily without any coding problem.<strong>Use full width page for best view and to use this plugin please add [user-dashboard] in your page editor from backend</strong>
Version: 1.0.0
Author: anil kumar
Author URI: http://about.me/anilDhiman
License: GPLv2 or later
*/
include( plugin_dir_path( __FILE__ ) . 'includes.php');

function udashboard(){
	$action	=	(isset($_REQUEST['ac'])) ? $_REQUEST['ac'] : 'none';
	switch($action){
		case 'login':
			MJdashboard::LoggedInUser();
			MJdashboard::LoggedProcess();
			MJdashboard::LogScreen();
		break;
		case 'dashboard':
			MJdashboard::LoggedoutUser();
			MJdashboard::Dashboard();
		break;
		case 'lostpass':
			MJdashboard::LoggedInUser();
			MJdashboard::PassProcess();
			MJdashboard::Lostpassword();
		break;
		case 'registration':
			MJdashboard::LoggedInUser();
			MJdashboard::RegProcess();
			MJdashboard::Registration();
		break;
		case 'profile':
			MJdashboard::LoggedoutUser();
			MJdashboard::ProProcess();
			MJdashboard::profile();
		break;
		case 'profileimage':
			MJdashboard::LoggedoutUser();
			MJdashboard::imageprocess();
			MJdashboard::Imageupload();
		break;
		case 'myclasses':
			MJdashboard::LoggedoutUser();
			MJdashboard::myclasses();
		break;
		case 'mypayment':
			MJdashboard::LoggedoutUser();
			MJdashboard::Mypayment();
		break;
		case 'requestsession':
			MJdashboard::LoggedoutUser();
			MJdashboard::Rqsession();
		break;
		case 'createsession':
			MJdashboard::LoggedoutUser();
			MJdashboard::Crsession();
		break;
		default:
			MJdashboard::LoggedInUser();
			MJdashboard::LoggedProcess();
			MJdashboard::Logincontrols();
		break;
	}	
}
function setting_page(){
	MJadmin::SettingPage();
}

function profileimage_shrotcode(){
	MJdashboard::LoggedoutUser();
	MJdashboard::imageprocess();
	MJdashboard::Imageupload();
}

function profile_shrotcode(){
	MJdashboard::LoggedoutUser();
	MJdashboard::ProProcess();
	MJdashboard::profile();
}

function myclass_shrotcode(){
	MJdashboard::LoggedoutUser();
	MJdashboard::Myclasses();
}

function mypayment_shrotcode(){
	MJdashboard::LoggedoutUser();
	MJdashboard::Mypayment();
}

function rqsession_shrotcode(){
	MJdashboard::LoggedoutUser();
	MJdashboard::Rqsession();
}

function crsession_shrotcode(){
	MJdashboard::LoggedoutUser();
	MJdashboard::Crsession();
}
add_shortcode('teacher-crsession','crsession_shrotcode');
add_shortcode('teacher-rqsession','rqsession_shrotcode');
add_shortcode('users-mypayment','mypayment_shrotcode');
add_shortcode('users-myclass','myclass_shrotcode');
add_shortcode('user-dashboard','udashboard');
add_shortcode('profile-dashboard','profileimage_shrotcode');
add_shortcode('profile-edit-dashboard','profile_shrotcode');
?>